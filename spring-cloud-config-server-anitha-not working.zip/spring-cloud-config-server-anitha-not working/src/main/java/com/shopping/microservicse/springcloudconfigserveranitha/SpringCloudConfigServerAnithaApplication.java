package com.shopping.microservicse.springcloudconfigserveranitha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class SpringCloudConfigServerAnithaApplication {
		
	    public static void main(String[] args) {
		SpringApplication.run(SpringCloudConfigServerAnithaApplication.class, args);
	}

}
